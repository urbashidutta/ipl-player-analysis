# 🏏 IPL Player Performance Analysis

A beginner-friendly data analysis project using Python, pandas, and matplotlib.

## 📌 Highlights
- Top run scorers and wicket takers
- Team-wise performance
- Visual insights with bar charts

## 📊 Tools Used
- Python
- pandas
- matplotlib
- seaborn

## 📁 Dataset
Sample IPL stats data (runs, wickets, matches)

## 🚀 How to Run
Open `ipl_analysis.ipynb` in Jupyter Notebook or VS Code.
